options(scipen=8)
library(tableone)
library(Matching)
library(sandwich)
library(survey)
library(ipw)

library(MatchIt)
data(lalonde, overwrite = FALSE)
original_lalonde <- lalonde
library(data.table)

## need this package reference
data(lalonde, package = 'MatchIt')
## TRUE
all.equal(original_lalonde, lalonde)

library(tidyr)
library(dplyr)

one <- lalonde
# response is real earnings in 1978
one <- one %>%
  rename(resp = re78)


preds  <- setdiff(colnames(one), c("treat","resp"))
confounding_preds <- c("age", "educ", "black", "hisp",
                       "married", "nodegree", "re74", "re75")

one$black<-as.numeric(one$race=='black')
one$hisp <-as.numeric(one$race=='hispan')


## Find the standardized differences for all of the
## confounding variables (pre-matching). What is the standardized difference
## for married (to nearest hundredth)?
##   SMD AKA standardized difference, although M is mean
table1 <- tableone::CreateTableOne(vars = confounding_preds, strata = "treat",
                                   data = one, test = FALSE)
## include standardized mean difference
print(table1, smd = TRUE)
# race
setdiff(preds, confounding_preds)

earnings_trt   <- mean(one %>% dplyr::filter(treat==1) %>%
                       dplyr::pull(resp))
earnings_notrt <- mean(one %>% dplyr::filter(treat==0) %>%
                       dplyr::pull(resp))
mean(earnings_trt) - mean(earnings_notrt)

## Fit a
## propensity score model. Use a logistic regression model, where the outcome is
## treatment. Include the 8 confounding variables in the model as predictors, with
## no interaction terms or non-linear terms (such as squared terms). Obtain the
## propensity score for each subject.
model_frm <- one %>% select(treat, confounding_preds)
# fit a propensity model, logistic regression
prop_model <- glm(treat ~ .,
                  family = binomial(), data = model_frm)
# show coefficients, etc.
summary(prop_model)
# create propensity score
pscore <- prop_model$fitted.values
# minimum and max of estimated propensity scores
min(pscore)
max(pscore)

set.seed(931139)
## Use options to specify pair
## matching, without replacement, no caliper.
##
## Match on the propensity score itself, not logit of the propensity score.
## Obtain the standardized differences
## for the matched data.
##
## M = 1 is one:one matching (default).
## Instructions did not specify one:one matching
psmatch <- Match(Tr = model_frm$treat, M = 1,
                  X = pscore, replace = FALSE)
matched <- model_frm[unlist(psmatch[c("index.treated","index.control")]),]


table1_ps <- tableone::CreateTableOne(vars = confounding_preds, strata = "treat",
                                      data = matched, test = FALSE)
print(table1_ps, smd = TRUE)

set.seed(931139)
psmatch2 <- Match(Tr = one$treat, M = 1,
                  X = pscore, replace = FALSE, caliper = 0.1)
matched2 <- one[unlist(psmatch2[c("index.treated","index.control")]),]

table1_ps2 <- tableone::CreateTableOne(vars = confounding_preds, strata = "treat",
                                       data = one, test = FALSE)
print(table1_ps2, smd = TRUE)

earnings_trt   <- mean(matched2 %>% dplyr::filter(treat==1) %>%
                         dplyr::pull(resp))
earnings_notrt <- mean(matched2 %>% dplyr::filter(treat==0) %>%
                         dplyr::pull(resp))
mean(earnings_trt) - mean(earnings_notrt)

## outcome analysis , paired t-test
out_trt <- matched2$resp[matched2$treat == 1]
out_con <- matched2$resp[matched2$treat == 0]

# pairwise difference
diffy   <- out_trt - out_con

# paired t-test
t.test(diffy)

## IPTW section
## now get inverse probability treatment weights
### first fit propensity score model
model_frm <- one %>% dplyr::select(treat, confounding_preds)
prop_model <- glm(treat ~ .,
                  family = binomial(), data = model_frm)
### value of propensity score for each subject
ps <- predict(prop_model, type = "response")

### create weights
weights <- ifelse(model_frm$treat==1, 1/ps, 1/(1-ps))
### min and max weights
min(weights)
max(weights)
### apply weights to data
weighteddata <- survey::svydesign(ids = ~1, data = one,
                                  weights = weights)
### weighted table 1
weightedtable <- tableone::svyCreateTableOne(
  vars = confounding_preds, strata = "treat",
  data = weighteddata, test = FALSE)
### show table with SMD
#### what is the standard difference for nodegree
print(weightedtable, smd = TRUE)
### fit a marginal structural model (risk difference)
### to model causal effects of treatment on the treated
msm <- (svyglm(resp ~ treat,
               design =
                 svydesign(~ 1, weights = ~weights,
                           data = one)))
### get causal relative risk. Weighted GLM
glm.obj <- glm(resp ~ treat,
               weights = weights,
               family=gaussian,
               data = one)
### treatment not predictor of response: real earnings in 1978
### treatment is 1 if received labor training
summary(glm.obj)
betaIPTW <- coef(msm)
confint(msm)

### fit propensity score model to get weights, but truncated
###  https://www.coursera.org/learn/crash-course-in-causality/resources/DTosM

# does not seem to matter
one_new <- fread('https://raw.githubusercontent.com/oksanab00/Crash_Course_Causality/main/lalonde.csv')
one_new <- one_new %>%
  rename(resp = re78)
model_frm <- one %>% dplyr::select(treat, confounding_preds)
weightmodel <- ipwpoint(exposure = treat, family = "binomial", link ="logit",
                        denominator= ~ age + educ + black + hisp + married +
                                       nodegree + re74 + re75,
                        data=model_frm,trunc=.01)

#numeric summary of weights
summary(weightmodel$weights.trun)
#plot of weights
ipwplot(weights = weightmodel$weights.trun, logscale = FALSE,
        main = "weights", xlim = c(0, 22))
one2 <- one
one2$wt <- weightmodel$weights.trun
#fit a marginal structural model (risk difference)
msm <- (svyglm(resp ~ treat, design = svydesign(~ 1, weights = ~wt,
                                                data = one2)))
coef(msm)
confint(msm)
